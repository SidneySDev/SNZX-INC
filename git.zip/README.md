#  SNZX-INC 
Plugin Abertura de Chamado Entre Zabbix 6 e o Service Now
