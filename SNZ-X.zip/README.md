#  SNZX-INC 
<stronger>Plugin Abertura de Chamado Entre Zabbix 6 e o Service Now</stronger>
![Imagem do WhatsApp de 2025-02-08 à(s) 02 47 37_e5bebcb1](https://github.com/user-attachments/assets/85ab11a5-aef7-4466-a618-8c332d8d016b)
