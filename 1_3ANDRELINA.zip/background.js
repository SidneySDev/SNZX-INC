// ==================================================
// Variáveis Globais
// ==================================================
let selectedText = '';

// ==================================================
// Funções Utilitárias
// ==================================================

async function obterSaudacao() {
  try {
    const now = new Date();
    const horaAtual = now.getHours();

    if (horaAtual >= 5 && horaAtual < 12) return "Bom dia";
    else if (horaAtual >= 12 && horaAtual < 18) return "Boa tarde";
    else return "Boa noite";
  } catch (error) {
    console.error('Erro ao obter a hora:', error);
    return "Olá";
  }
}

async function gerarCorpoEmail(hosts) {
  try {
    const saudacao = await obterSaudacao();
    return `
Prezados, ${saudacao}!
Favor verificar a causa da falha nos hosts abaixo e enviar o protocolo de acompanhamento.

${hosts.map(host => `- Host: ${host.nome}\n  Designação: ${host.designador}`).join('\n')}

Atenciosamente,
    `.trim();
  } catch (error) {
    console.error('Erro ao gerar o corpo do email:', error);
    return `
Prezados, Olá!

Favor verificar a causa da falha nos hosts abaixo e enviar o protocolo de acompanhamento.

${hosts.map(host => `- Host: ${host.nome}\n  Designação: ${host.designador}`).join('\n')}

Atenciosamente,
    `.trim();
  }
}



// ==================================================
// Função específica para Embratel (EBT) - Versão com Formatos Diferentes
// ==================================================

async function gerarCorpoEmailEbt(hosts) {
  try {
    const saudacao = await obterSaudacao();
    
    // Se for apenas UM host
    if (hosts.length === 1) {
      const host = hosts[0];
      return `
Prezados, ${saudacao.toLowerCase()}!
Favor realizar abertura de chamado para solicitação de link abaixo:

Localidade: 
Horário da falha: 
Status: 
Contatos: (98)20550555 / noc.cgs@equatorialtelecom.com.br
Horários: 24x7
Atribuir a: quem atender
Designador: ${host.designador || 'NÃO CADASTRADO NA BASE, CONSULTAR ZABBIX'}
Protocolo Interno:
Reset: Sim(  ) Não(  )
Equipamento energizado: Sim(  ) Não(  )
Sintoma:
      `.trim();
    }
    
    // Se for MÚLTIPLOS hosts
    const listaHosts = hosts.map(host => {
      return `Host: ${host.nome}
Designador: ${host.designador || 'NÃO CADASTRADO NA BASE, CONSULTAR ZABBIX'}`;
    }).join('\n\n');

    return `
Prezados, ${saudacao.toLowerCase()}!
Favor realizar abertura de chamado para solicitação de link abaixo:

Localidade: 
Horário da falha: 
Status: 
Contatos: (98)20550555 / noc.cgs@equatorialtelecom.com.br
Horários: 24x7
Atribuir a: quem atender

${listaHosts}

Protocolo Interno:
Reset: Sim(  ) Não(  )
Equipamento energizado: Sim(  ) Não(  )
Sintoma:

    `.trim();
    
  } catch (error) {
    console.error('Erro ao gerar o corpo do email para Embratel:', error);
    return `
Prezados, ${saudacao.toLowerCase()}!
Favor realizar abertura de chamado para solicitação de link abaixo:

Localidade: 
Horário da falha: 
Status: 
Contatos: (98)20550555 / noc.cgs@equatorialtelecom.com.br
Horários: 24x7
Atribuir a: quem atender
Designador: 
Protocolo Interno:
Reset: Sim(  ) Não(  )
Equipamento energizado: Sim(  ) Não(  )
Sintoma:

    `.trim();
  }
}

// ==================================================
// Função fillFields Original (Versão Funcionando)
// ==================================================

function fillFields(selectedText) {
  console.log('Preenchendo campos...');

  const fixedData = {
    caller: 'u8800218',
    item: 'Telecom e Redes - Problemas Gerais',
    symptom: 'Indisponível',
    businessService: 'Radio e Telecomunicação',
    assignmentGroup: 'Monitoramento CGS'
  };

  function fillField(element, value, callback) {
    if (element) {
      element.focus();
      element.value = '';
      let i = 0;
      const typingInterval = setInterval(() => {
        if (i < value.length) {
          element.value += value[i];
          const inputEvent = new Event('input', { bubbles: true });
          element.dispatchEvent(inputEvent);
          const keydownEvent = new Event('keydown', { bubbles: true });
          element.dispatchEvent(keydownEvent);
          i++;
        } else {
          const changeEvent = new Event('change', { bubbles: true });
          element.dispatchEvent(changeEvent);
          clearInterval(typingInterval);
          if (callback) callback();
        }
      }, 2.5);
    }
  }

  function getLocationFromDescription(description) {
    const regex = /(EQTAL-CL|EQTAL-CC|EQTMA-CL|EQTPA-PA|EQTPI-CL|EQTRS|EQTMA|EQTPI|EQTAL|EQTAP|EQTTR|EQTPA|EQTGO)/;
    const match = description.match(regex);

    if (match) {
      const prefix = match[1];
      switch (prefix) {
        case 'EQTRS': return 'EQTL CEEE';
        case 'EQTMA': return 'EQTL Maranhão';
        case 'EQTPI': return 'EQTL Piauí';
        case 'EQTAL': return 'EQTL Alagoas';
        case 'EQTAP': return 'EQTL Amapá';
        case 'EQTTR': return 'COS Equatorial Transmissão';
        case 'EQTPA': return 'EQTL Pará';
        case 'EQTGO': return 'EQTL Goiás';
        case 'EQTAL-CL': return 'Cliente Livre AL';
        case 'EQTAL-CC': return 'Cliente Cativo AL';
        case 'EQTMA-CL': return 'Cliente Livre MA';
        case 'EQTPA-PA': return 'Cliente Livre PA';
        case 'EQTPI-CL': return 'Cliente Livre PI';
        default: return 'EQTL Energia';
      }
    }
    return 'EQTL Energia';
  }

  // Função de notificação estilizada
  function showNotification(incNumber) {
    const notification = document.createElement('div');
    notification.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    padding: 15px;
    background: rgba(0, 0, 0, 0.7);
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
    border-radius: 10px;
    color: white;
    z-index: 9999;
    max-width: 300px;
    word-break: break-word;
    border: 1px solid rgba(255, 255, 255, 0.2);
    animation: fadeIn 0.3s ease-in-out;
  `;

    const messageDiv = document.createElement('div');
    messageDiv.style.marginBottom = '10px';
    messageDiv.style.fontWeight = 'bold';
    messageDiv.textContent = `${incNumber} - Gerado para acompanhamento.`;

    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.gap = '10px';
    buttonContainer.style.justifyContent = 'flex-end';

    const copyButton = document.createElement('button');
    copyButton.id = 'copy-btn';
    copyButton.textContent = 'Copiar';
    copyButton.style.cssText = `
    padding: 5px 10px;
    border-radius: 5px;
    border: none;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    cursor: pointer;
  `;

    const closeButton = document.createElement('button');
    closeButton.id = 'close-btn';
    closeButton.textContent = 'Fechar';
    closeButton.style.cssText = `
    padding: 5px 10px;
    border-radius: 5px;
    border: none;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    cursor: pointer;
  `;

    buttonContainer.appendChild(copyButton);
    buttonContainer.appendChild(closeButton);

    notification.appendChild(messageDiv);
    notification.appendChild(buttonContainer);

    const style = document.createElement('style');
    style.textContent = `
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
    document.head.appendChild(style);

    document.body.appendChild(notification);

    copyButton.addEventListener('click', () => {
      navigator.clipboard.writeText(`${incNumber} - Gerado para acompanhamento`);
      copyButton.textContent = 'Copiado!';
      setTimeout(() => {
        if (notification.parentNode) {
          copyButton.textContent = 'Copiar';
        }
      }, 2000);
    });

    closeButton.addEventListener('click', () => {
      notification.remove();
      document.head.removeChild(style);
    });

    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
        if (document.head.contains(style)) {
          document.head.removeChild(style);
        }
      }
    }, 10000);
  }

  function fillFieldsSequentially() {
    const callerField = document.getElementById('sys_display.incident.caller_id');
    const locationField = document.getElementById('sys_display.incident.location');
    const itemField = document.getElementById('sys_display.incident.u_item');
    const symptomField = document.getElementById('sys_display.incident.u_symptom');
    const businessServiceField = document.getElementById('sys_display.incident.business_service');
    const assignmentGroupField = document.getElementById('sys_display.incident.assignment_group');
    const descriptionField = document.getElementById('incident.description');
    const workNotesField = document.getElementById('incident.work_notes');
    const numberField = document.getElementById('sys_readonly.incident.number');

    if (callerField && locationField && itemField && symptomField &&
      businessServiceField && assignmentGroupField && descriptionField && workNotesField) {
      const locationValue = getLocationFromDescription(selectedText);

      fillField(callerField, fixedData.caller, () => {
        fillField(locationField, locationValue, () => {
          fillField(itemField, fixedData.item, () => {
            fillField(symptomField, fixedData.symptom, () => {
              fillField(businessServiceField, fixedData.businessService, () => {
                fillField(assignmentGroupField, fixedData.assignmentGroup, () => {
                  descriptionField.value = selectedText;
                  descriptionField.dispatchEvent(new Event('input', { bubbles: true }));
                  descriptionField.dispatchEvent(new Event('change', { bubbles: true }));

                  workNotesField.value = selectedText;
                  workNotesField.dispatchEvent(new Event('input', { bubbles: true }));
                  workNotesField.dispatchEvent(new Event('change', { bubbles: true }));

                  const maxAttempts = 30;
                  let attempts = 0;
                  const checkInterval = 500;

                  const checkNumberInterval = setInterval(() => {
                    attempts++;

                    if (numberField && numberField.value && numberField.value.trim() !== '') {
                      clearInterval(checkNumberInterval);
                      showNotification(numberField.value.trim());
                    } else if (attempts >= maxAttempts) {
                      clearInterval(checkNumberInterval);
                    }
                  }, checkInterval);
                });
              });
            });
          });
        });
      });
    } else {
      console.error('Campos não encontrados');
    }
  }

  setTimeout(fillFieldsSequentially, 400);
}

// ==================================================
// Funções para Abertura de Chamados
// ==================================================

async function abrirChamadoGenerico(selectedText, urlJson, destinatario, copia, gerarCorpoEmailFn = gerarCorpoEmail) {
  if (!selectedText?.trim()) {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, selecione hosts válidos.",
      iconUrl: "icon.png"
    });
    return;
  }

  try {
    const response = await fetch(urlJson);
    if (!response.ok) throw new Error('Erro ao carregar lista de equipamentos');

    const data = await response.json();
    const equipamentos = data.equipamentos;
    const hostnamesSelecionados = selectedText.split(/[\n,]/).map(host => host.trim());

    const designadores = hostnamesSelecionados.map(hostname => {
      const equipamento = equipamentos.find(eq => eq.hostname === hostname);
      return equipamento ?
        { nome: hostname, designador: equipamento.designador } :
        { nome: hostname, designador: 'NÃO ENCONTRADO' };
    });

    if (designadores.length === 0) {
      browser.notifications.create({
        type: "basic",
        title: "Erro",
        message: "Nenhum designador encontrado para os hosts selecionados.",
        iconUrl: "icon.png"
      });
      return;
    }

    const corpoEmail = await gerarCorpoEmailFn(designadores);
    const subject = 'Abertura de chamado - ';
    const outlookWebUrl = `https://outlook.office365.com/mail/deeplink/compose?to=${encodeURIComponent(destinatario)}&cc=${encodeURIComponent(copia)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(corpoEmail)}`;

    browser.tabs.create({ url: outlookWebUrl });

  } catch (error) {
    console.error(`Erro ao abrir chamado:`, error);
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Falha ao processar a requisição. Verifique o console para detalhes.",
      iconUrl: "icon.png"
    });
  }
}

async function abrirChamadoTPZ(selectedText) {
  await abrirChamadoGenerico(
    selectedText,
    'https://raw.githubusercontent.com/SidneySDev/SNZX-INC/main/basetpz.json',
    'TPZ.BR.TAC@telespazio.com',
    'noc.cgs@equatorialtelecom.com.br'
  );
}

async function abrirChamadoHughes(selectedText) {
  await abrirChamadoGenerico(
    selectedText,
    'https://raw.githubusercontent.com/SidneySDev/SNZX-INC/main/hughes.json',
    'helpdesk@hughes.com.br',
    'noc.cgs@equatorialtelecom.com.br'
  );
}

async function abrirChamadoEbt(selectedText) {
  await abrirChamadoGenerico(
    selectedText,
    'https://raw.githubusercontent.com/SidneySDev/SNZX-INC/main/ebt.json',
    'chamado@claroatendimento.com.br',
    'noc.cgs@equatorialtelecom.com.br',
    gerarCorpoEmailEbt // Usando a função específica para Embratel
  );
}

// ==================================================
// Funções ServiceNow
// ==================================================

function openServiceNow(selectedText) {
  if (!selectedText || selectedText.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, selecione um texto válido.",
      iconUrl: "icon.png"
    });
    return;
  }

  const serviceNowUrl = 'https://equatorialenergia.service-now.com/incident.do?sys_id=-1';

  browser.tabs.create({ url: serviceNowUrl }).then((tab) => {
    const listener = (tabId, changeInfo) => {
      if (tabId === tab.id && changeInfo.status === 'complete') {
        browser.tabs.onUpdated.removeListener(listener);

        setTimeout(() => {
          browser.tabs.executeScript(tab.id, {
            code: `(${fillFields.toString()})(${JSON.stringify(selectedText)})`
          }).catch(error => {
            console.error('Erro ao injetar script:', error);
          });
        }, 1800);
      }
    };
    browser.tabs.onUpdated.addListener(listener);
  });
}

function consultarChamadoServiceNow(ticketNumber) {
  if (!ticketNumber || ticketNumber.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, insira um número válido (INC, RITM, KB ou SCTASK).",
      iconUrl: "icon.png"
    });
    return;
  }

  const numeroFormatado = ticketNumber.trim().toUpperCase();
  let serviceNowUrl;

  if (numeroFormatado.startsWith('INC')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/incident.do?sysparm_query=number=${numeroFormatado}`;
  }
  else if (numeroFormatado.startsWith('RITM')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/sc_req_item.do?sysparm_query=number=${numeroFormatado}`;
  }
  else if (numeroFormatado.startsWith('SCTASK')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/sc_task.do?sysparm_query=number=${numeroFormatado}`;
  }
  else if (numeroFormatado.startsWith('KB')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/kb_view.do?sysparm_article=${numeroFormatado}`
  }
  else {
    browser.notifications.create({
      type: "basic",
      title: "Formato Inválido",
      message: "Use: INC, RITM, KB ou SCTASK seguido de números",
      iconUrl: "icon.png"
    });
    return;
  }

  browser.tabs.create({ url: serviceNowUrl });
}

// ==================================================
// Função para Consultar Chamado Voalle
// ==================================================

function consultarChamadoVoalle(ticketNumber) {
  if (!ticketNumber || ticketNumber.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, insira um número de chamado válido",
      iconUrl: "icon.png"
    });
    return;
  }

  const numeroLimpo = ticketNumber.replace(/\D/g, '');

  if (!numeroLimpo) {
    browser.notifications.create({
      type: "basic",
      title: "Formato Inválido",
      message: "O número do chamado deve conter apenas dígitos",
      iconUrl: "icon.png"
    });
    return;
  }

  const voalleUrl = `https://erp.equatorialtelecom.com.br/attendance#/customer-attendance/${numeroLimpo}`;
  browser.tabs.create({ url: voalleUrl });
}

// ==================================================
// Função para Consultar Múltiplos Chamados (SNZ-B)
// ==================================================

function consultarMultiplosChamados(selectedText) {
  if (!selectedText || selectedText.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, selecione texto válido com números de chamado.",
      iconUrl: "icon.png"
    });
    return;
  }

  browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
    if (tabs[0]) {
      browser.tabs.sendMessage(tabs[0].id, {
        action: "processarTextoSelecionado",
        texto: selectedText.trim()
      }).catch(error => {
        console.error('Erro ao enviar mensagem para content script:', error);
        browser.notifications.create({
          type: "basic",
          title: "Erro",
          message: "Não foi possível processar os chamados. Verifique se está em uma página compatível.",
          iconUrl: "icon.png"
        });
      });
    }
  });
}

// ==================================================
// Configuração do Menu de Contexto
// ==================================================

function setupContextMenu() {
  browser.contextMenus.create({
    id: 'openServiceNow',
    title: '📋 Abrir Chamado ServiceNow',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'consultarChamadoServiceNow',
    title: '🔍 Consultar Página ServiceNow',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'consultarMultiplosChamados',
    title: '📊 Consultar Status INC',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'consultarChamadoVoalle',
    title: '📑 Consultar Chamado Voalle',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'abrirChamadoTPZ',
    title: '📨 Abrir Chamado TPZ',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'abrirChamadoHughes',
    title: '📨 Abrir Chamado Hughes',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'abrirChamadoEbt',
    title: '📨 Abrir Chamado Embratel',
    contexts: ['selection']
  });
}

// ==================================================
// Listener do Menu de Contexto
// ==================================================

browser.contextMenus.onClicked.addListener((info, tab) => {
  selectedText = info.selectionText;

  switch (info.menuItemId) {
    case 'openServiceNow':
      openServiceNow(selectedText);
      break;
    case 'abrirChamadoTPZ':
      abrirChamadoTPZ(selectedText);
      break;
    case 'abrirChamadoHughes':
      abrirChamadoHughes(selectedText);
      break;
    case 'abrirChamadoEbt':
      abrirChamadoEbt(selectedText);
      break;
    case 'consultarChamadoServiceNow':
      consultarChamadoServiceNow(selectedText);
      break;
    case 'consultarChamadoVoalle':
      consultarChamadoVoalle(selectedText);
      break;
    case 'consultarMultiplosChamados':
      consultarMultiplosChamados(selectedText);
      break;
  }

  selectedText = '';
});

// ==================================================
// Listeners de Atalhos de Teclado
// ==================================================

browser.commands.onCommand.addListener((command) => {
  browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
    if (tabs[0]) {
      browser.tabs.executeScript(tabs[0].id, {
        code: "window.getSelection().toString();"
      }).then((results) => {
        const selectedText = results[0] || '';

        switch (command) {
          case 'open-servicenow':
            openServiceNow(selectedText);
            break;
          case 'consultar-chamado':
            consultarChamadoServiceNow(selectedText);
            break;
          case 'consultar-multiplos':
            consultarMultiplosChamados(selectedText);
            break;
        }
      }).catch(error => {
        console.error('Erro ao obter texto selecionado:', error);
      });
    }
  });
});

// ==================================================
// Inicialização
// ==================================================

setupContextMenu();