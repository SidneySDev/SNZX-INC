// ======================
// Configurações Globais
// ======================
let processoAtivo = false;
let controller = null;
let progressoTotal = 0;
let selectedTurn = null;
let usarNegrito = false;
let usarDash = false;
let overlayAtual = null;
let atualizandoChamados = false;

// ======================
// Funções Auxiliares
// ======================
function getSaudacao(date) {
    const hora = date.getHours();
    if (hora < 6) return 'Boa madrugada';
    if (hora < 12) return 'Bom dia';
    if (hora < 18) return 'Boa tarde';
    return 'Boa noite';
}

function formatarData(date) {
    const dia = String(date.getDate()).padStart(2, '0');
    const mes = String(date.getMonth() + 1).padStart(2, '0');
    const ano = date.getFullYear();
    return `${dia}/${mes}/${ano}`;
}

function resetarEstadosGlobais() {
    selectedTurn = null;
    usarNegrito = false;
    usarDash = false;
    processoAtivo = false;
    atualizandoChamados = false;
    if (controller) {
        controller.abort();
        controller = null;
    }
}

function resetarAparenciaBotoes() {
    const botoesTurno = document.querySelectorAll('[data-id="T1"], [data-id="T2"], [data-id="T3"]');
    const botaoNegrito = document.querySelector('[data-id="N"]');
    const botaoDash = document.querySelector('[data-id="dash"]');

    botoesTurno.forEach(botao => {
        botao.style.background = '#f0f0f0';
        botao.style.color = '#333';
        botao.style.borderColor = '#ddd';
    });

    if (botaoNegrito) {
        botaoNegrito.style.background = '#f0f0f0';
        botaoNegrito.style.color = '#333';
        botaoNegrito.style.borderColor = '#ddd';
    }

  if (botaoDash) {
        botaoDash.style.background = '#f0f0f0';
        botaoDash.style.color = '#333';
        botaoDash.style.borderColor = '#ddd';
    }
}

// ======================
// Funções de UI - Tema de Energia Elétrica Azul
// ======================
function exibirLoading(totalChamados) {
    try {
        progressoTotal = totalChamados;

        const overlay = document.createElement('div');
        overlay.id = 'snzx-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,20,0.9);
            z-index: 9999;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        `;

        // Efeito de partículas de energia azul
        const particlesContainer = document.createElement('div');
        particlesContainer.style.cssText = `
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        `;
        overlay.appendChild(particlesContainer);

        // Criar partículas azuis
        for (let i = 0; i < 15; i++) {
            const particle = document.createElement('div');
            particle.style.cssText = `
                position: absolute;
                width: 2px;
                height: 2px;
                background: #64B5F6;
                border-radius: 50%;
                box-shadow: 0 0 10 2px #42A5F5;
                animation: float ${3 + Math.random() * 4}s infinite ease-in-out;
                opacity: ${0.3 + Math.random() * 0.7};
            `;
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.top = `${Math.random() * 100}%`;
            particle.style.animationDelay = `${Math.random() * 5}s`;
            particlesContainer.appendChild(particle);
        }

        const container = document.createElement('div');
        container.style.cssText = `
            width: 380px;
            background: rgba(5, 10, 30, 0.9);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 25px rgba(66, 165 245, 0.4);
            text-align: center;
            position: relative;
            z-index: 1;
            border: 1px solid rgba(100, 181, 246, 0.3);
        `;

        const texto = document.createElement('div');
        texto.textContent = 'PROCESSANDO CHAMADOS...';
        texto.style.cssText = `
            margin-bottom: 20px;
            font-weight: bold;
            font-size: 18px;
            color: #64B5F6;
            letter-spacing: 1px;
            text-shadow: 0 0 8px rgba(66, 165, 245, 0.5);
        `;
        container.appendChild(texto);

        const progressContainer = document.createElement('div');
        progressContainer.style.cssText = `
            height: 25px;
            background: rgba(10, 20, 40, 0.8);
            border-radius: 12px;
            margin-bottom: 20px;
            overflow: hidden;
            position: relative;
            box-shadow: inset 0 0 10px rgba(0,0,0,0.5);
            border: 1px solid rgba(66, 165, 245, 0.3);
        `;

        const progressBar = document.createElement('div');
        progressBar.style.cssText = `
            height: 100%;
            width: 0%;
            background: linear-gradient(90deg, 
                rgba(33, 150, 243, 0.8) 0%, 
                rgba(30, 136, 229, 0.9) 50%, 
                rgba(25, 118, 210, 1) 100%);
            border-radius: 12px;
            transition: width 0.4s ease;
            position: relative;
            overflow: hidden;
        `;
        progressBar.id = 'progressBar';

        const progressPulse = document.createElement('div');
        progressPulse.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                rgba(255, 255, 255, 0) 0%, 
                rgba(224, 247, 255, 0.6) 50%, 
                rgba(255, 255, 255, 0) 100%);
            animation: pulse 1.5s infinite;
            transform: translateX(-100%);
        `;
        progressBar.appendChild(progressPulse);
        progressContainer.appendChild(progressBar);
        container.appendChild(progressContainer);

        const lightningEffect = document.createElement('div');
        lightningEffect.style.cssText = `
            position: absolute;
            top: -5px;
            left: -5px;
            right: -5px;
            bottom: -5px;
            border-radius: 15px;
            border: 2px solid transparent;
            animation: lightning 3s infinite linear;
            pointer-events: none;
            z-index: -1;
        `;
        container.appendChild(lightningEffect);

        const counter = document.createElement('div');
        counter.id = 'progressCounter';
        counter.textContent = '0/0';
        counter.style.cssText = `
            font-size: 14px;
            color: #64B5F6;
            font-weight: 600;
            letter-spacing: 1px;
            text-shadow: 0 0 5px rgba(66, 165, 245, 0.3);
        `;
        container.appendChild(counter);

        const style = document.createElement('style');
        style.textContent = `
            @keyframes float {
                0%, 100% { transform: translate(0, 0); }
                50% { transform: translate(${Math.random() * 20 - 10}px, ${Math.random() * 20 - 10}px); }
            }
            @keyframes pulse {
                0% { transform: translateX(-100%); }
                100% { transform: translateX(100%); }
            }
            @keyframes lightning {
                0% { border-color: transparent; box-shadow: 0 0 0 rgba(66, 165, 245, 0); }
                70% { border-color: transparent; box-shadow: 0 0 0 rgba(66, 165, 245, 0); }
                71% { border-color: #42A5F5; box-shadow: 0 0 15px rgba(66, 165, 245, 0.8); }
                72% { border-color: transparent; box-shadow: 0 0 0 rgba(66, 165, 245, 0); }
                85% { border-color: transparent; box-shadow: 0 0 0 rgba(66, 165, 245, 0); }
                86% { border-color: #64B5F6; box-shadow: 0 0 10px rgba(100, 181, 246, 0.8); }
                87% { border-color: transparent; box-shadow: 0 0 0 rgba(66, 165, 245, 0); }
                100% { border-color: transparent; box-shadow: 0 0 0 rgba(66, 165, 245, 0); }
            }
        `;
        document.head.appendChild(style);

        overlay.appendChild(container);
        document.body.appendChild(overlay);
        overlayAtual = overlay;
        return overlay;
    } catch (error) {
        console.error('Erro ao exibir loading:', error);
        return null;
    }
}

function atualizarProgresso(atual, total) {
    const progressBar = document.getElementById('progressBar');
    const counter = document.getElementById('progressCounter');

    if (progressBar) {
        const porcentagem = Math.round((atual / total) * 100);
        progressBar.style.width = `${porcentagem}%`;

        if (porcentagem < 30) {
            progressBar.style.background = `linear-gradient(90deg, 
                rgba(66, 165, 245, 0.8) 0%, 
                rgba(33, 150, 243, 0.9) 50%, 
                rgba(30, 136, 229, 1) 100%)`;
        } else if (porcentagem < 70) {
            progressBar.style.background = `linear-gradient(90deg, 
                rgba(33, 150, 243, 0.8) 0%, 
                rgba(30, 136, 229, 0.9) 50%, 
                rgba(25, 118, 210, 1) 100%)`;
        } else {
            progressBar.style.background = `linear-gradient(90deg, 
                rgba(30, 136, 229, 0.8) 0%, 
                rgba(25, 118, 210, 0.9) 50%, 
                rgba(13, 71, 161, 1) 100%)`;
        }
    }

    if (counter) {
        counter.textContent = `${atual}/${total}`;
        counter.style.textShadow = '0 0 10px rgba(66, 165, 245, 0.8)';
        setTimeout(() => {
            counter.style.textShadow = '0 0 5px rgba(66, 165, 245, 0.3)';
        }, 300);
    }
}

function fecharLoading(overlay) {
    try {
        if (overlay && overlay.parentNode) {
            overlay.style.transition = 'opacity 0.3s ease';
            overlay.style.opacity = '0';
            setTimeout(() => {
                overlay.remove();
            }, 300);
        }
    } catch (error) {
        console.error('Erro ao fechar loading:', error);
    }
}

// ======================
// Funções Principais
// ======================
async function consultarChamado(numeroINC) {
    try {
        controller = new AbortController();
        const response = await fetch(
            `https://equatorialenergia.service-now.com/incident.do?sysparm_query=number=${numeroINC}`,
            { signal: controller.signal }
        );

        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

        const html = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        if (!doc) throw new Error('Falha ao parsear HTML');

        const estado = doc.getElementById('incident.state')?.querySelector('option[selected]')?.textContent || 'Desconhecido';
        const isStatusCritico = ['Validar Solução', 'Encerrado'].includes(estado);

        const closeNotesTextarea = doc.getElementById('incident.close_notes');
        const closeNotesValue = closeNotesTextarea?.value || '';

        if (isStatusCritico && closeNotesTextarea) {
            const requiredText = 'Link normalizado após reparo.';
            if (!closeNotesValue.includes(requiredText)) {
                closeNotesTextarea.value = requiredText;
                const event = new Event('change');
                closeNotesTextarea.dispatchEvent(event);
            }
        }

        return {
            numeroINC,
            estado,
            dataAbertura: doc.getElementById('sys_readonly.incident.sys_created_on')?.value || '--',
            ultimaAtividade: extrairUltimaAtividade(doc),
            tratativa: extrairTratativa(doc),
            closeNotes: isStatusCritico ? (closeNotesValue || 'Sem notas') : '',
            isStatusCritico,
            isEncerrado: estado === 'Encerrado' || estado === 'Validar Solução'
        };
    } catch (error) {
        if (error.name === 'AbortError') {
            console.warn(`Requisição abortada para ${numeroINC}`);
        } else {
            console.error(`Erro ao consultar ${numeroINC}:`, error);
        }
        return {
            numeroINC,
            estado: 'Erro na consulta - verifique sua autenticação no Service Now',
            dataAbertura: '--',
            ultimaAtividade: '--',
            tratativa: '--',
            closeNotes: '',
            isStatusCritico: false,
            isEncerrado: false
        };
    }
}

function extrairUltimaAtividade(doc) {
    try {
        // Método mais robusto para extrair a última atividade
        const atividades = doc.querySelectorAll('.sn-form-inline-stream-entry');
        if (atividades.length > 0) {
            const ultimaAtividade = atividades[atividades.length - 1];
            const dataElement = ultimaAtividade.querySelector('.date-calendar, .sn-widget-list-content-time');
            return dataElement?.textContent?.trim() || '--';
        }
        
        // Método alternativo
        const atividade = doc.getElementById('sn_form_inline_stream_entries')
            ?.querySelector('.h-card.h-card_md.h-card_comments');
        return atividade?.querySelector('.date-calendar')?.textContent?.trim() || '--';
    } catch (error) {
        console.error('Erro ao extrair última atividade:', error);
        return '--';
    }
}

function extrairTratativa(doc) {
    try {
        const atividades = doc.querySelectorAll('.sn-form-inline-stream-entry');
        if (atividades.length > 0) {
            const ultimaAtividade = atividades[atividades.length - 1];
            const descricao = ultimaAtividade.querySelector('.sn-widget-textblock-body, .activity-stream-text')?.textContent?.trim();
            return descricao || 'Consultar Chamado';
        }
        
        // Método alternativo
        const atividade = doc.getElementById('sn_form_inline_stream_entries')
            ?.querySelector('.h-card.h-card_md.h-card_comments');
        const descricao = atividade?.querySelector('.sn-widget-textblock-body')?.textContent?.trim() || 'Consultar Chamado';
        return descricao.includes('Sistema') ? 'Consultar Chamado' : descricao;
    } catch (error) {
        console.error('Erro ao extrair tratativa:', error);
        return 'Consultar Chamado';
    }
}

// ======================
// Função de Formatação para Copiar
// ======================
function formatarTextoParaCopiar(resultados) {
    try {
        const categorias = {
            emAndamento: resultados.filter(r => r.estado === 'Em Andamento'),
            emEspera: resultados.filter(r => String(r.estado).toLowerCase() === 'em espera'),
            pausado: resultados.filter(r => r.estado === 'Pausado'),
            encerradoValidacao: resultados.filter(r =>
                ['Encerrado', 'Validar Solução'].includes(r.estado)),
            naoProcessados: resultados.filter(r =>
                ['Erro na consulta', 'Desconhecido'].includes(r.estado) ||
                !['Em Andamento', 'Em Espera', 'Pausado', 'Validar Solução', 'Encerrado']
                    .some(e => String(e).toLowerCase() === String(r.estado).toLowerCase()))
        };

        let textoCompleto = '';
        const now = new Date();

        if (selectedTurn) {
            const saudacao = getSaudacao(now);
            const dataFormatada = formatarData(now);
            let turnoInfo = '';

            switch (selectedTurn.id) {
                case 'T1': turnoInfo = 'T1>T2'; break;
                case 'T2': turnoInfo = 'T2>T3'; break;
                case 'T3': turnoInfo = 'T3>T1'; break;
                default: turnoInfo = 'turno selecionado';
            }

            const negritoInicio = usarNegrito ? '*' : '';
            const negritoFim = usarNegrito ? '*' : '';

            textoCompleto += `${negritoInicio}${saudacao} - Diário de bordo ${turnoInfo} - ${dataFormatada}${negritoFim}\n\n` +
                `${negritoInicio}<<<<<EQTL ENERGIA>>>>>${negritoFim}\n\n`;
        }

        const formatarSecao = (titulo, chamados) => {
            if (!chamados || chamados.length === 0) return '';

            let tituloFormatado = `${titulo.toUpperCase()} (${chamados.length})`;
            if (usarNegrito) tituloFormatado = `*${tituloFormatado}*`;

            let textoSecao = `${tituloFormatado}\n\n`;

            chamados.forEach((result, index) => {
                const num = index + 1;
                let linhaChamado = `${num}. ${result.numeroINC}`;
                if (result.textoOriginal) linhaChamado += ` - ${result.textoOriginal}`;
                if (usarNegrito) linhaChamado = `*${linhaChamado}*`;

                const formatarRotulo = (rotulo, valor) => usarNegrito ? `*${rotulo}:* ${valor || ''}` : `${rotulo}: ${valor || ''}`;

                textoSecao += `${linhaChamado}\n` +
                    `${formatarRotulo('Tratativa', result.tratativa)}\n` +
                    `${formatarRotulo('Abertura', result.dataAbertura)}\n` +
                    `${formatarRotulo('Atualização', result.ultimaAtividade)}\n`;

                if (result.closeNotes) {
                    textoSecao += `${formatarRotulo('!!! NOTA DE ENCERRAMENTO', result.closeNotes)}\n`;
                }

                if (usarDash && index < chamados.length - 1) {
                    textoSecao += '────────────────────\n';
                } else {
                    textoSecao += '\n';
                }
            });

            return textoSecao;
        };

        const secoes = [
            { titulo: 'CHAMADOS EM ANDAMENTO', dados: categorias.emAndamento },
            { titulo: 'CHAMADOS EM ESPERA', dados: categorias.emEspera },
            { titulo: 'CHAMADOS PAUSADOS', dados: categorias.pausado },
            { titulo: 'CHAMADOS ENCERRADOS/VALIDAÇÃO', dados: categorias.encerradoValidacao },
            { titulo: 'NÃO PROCESSADOS - ERRO', dados: categorias.naoProcessados }
        ].filter(cat => cat.dados.length > 0)
            .map(cat => formatarSecao(cat.titulo, cat.dados));

        textoCompleto += secoes.join(usarDash ? '────────────────────\n' : '\n');
        return textoCompleto.trim();
    } catch (error) {
        console.error('Erro ao formatar texto:', error);
        return 'Erro ao formatar texto para copiar';
    }
}

// ======================
// Função para Criar Popup (ATUALIZADA com tema de energia azul)
// ======================
function criarPopup(resultados, totalChamados, chamadoAtualizando = null) {
    try {
        const popupExistente = document.querySelector('.popup-chamados, #snzx-overlay, #snzx-container');
        if (popupExistente) popupExistente.remove();

        if (overlayAtual && !atualizandoChamados) {
            fecharLoading(overlayAtual);
        }

        // Criar elemento de explosão para o botão X
        const explosionEffect = document.createElement('div');
        explosionEffect.style.cssText = `
            position: fixed;
            width: 10px;
            height: 10px;
            background: radial-gradient(circle, rgba(255,95,86,0.8) 0%, rgba(255,95,86,0) 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 10002;
            opacity: 0;
            transform: scale(0);
            transition: all 0.3s ease-out;
        `;
        document.body.appendChild(explosionEffect);

        // Criar container principal que envolve tudo
        const containerPrincipal = document.createElement('div');
        containerPrincipal.id = 'snzx-container';
        containerPrincipal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10000;
            display: flex;
            flex-direction: column;
            align-items: center;
        `;

        // Criar a marca SNZ-B flutuante acima do popup
        const marcaFlutuante = document.createElement('div');
        marcaFlutuante.textContent = 'SolluS';
        marcaFlutuante.style.cssText = `
            background: linear-gradient(135deg, #1565C0 0%, #0D47A1 100%);
            color: white;
            font-weight: 800;
            font-size: 14px;
            letter-spacing: 2px;
            padding: 8px 24px;
            border-radius: 20px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
            border: 1px solid rgba(100, 181, 246, 0.5);
            text-transform: uppercase;
            margin-bottom: -12px;
            z-index: 10001;
            position: relative;
        `;
        containerPrincipal.appendChild(marcaFlutuante);

        // Criar o popup
        const popup = document.createElement('div');
        popup.className = 'popup-chamados';
        popup.style.cssText = `
            width: 800px;
            max-height: 85vh;
            background: white; 
            border-radius: 14px;
            box-shadow: 0 12px 35px rgba(0,0,0,0.18);
            overflow: hidden;
            font-family: 'Segoe UI', system-ui, sans-serif;
            display: flex;
            flex-direction: column;
            border: 1px solid #e0e0e0;
        `;

        // Header con barra de progresso
        const header = document.createElement('div');
        header.style.cssText = `
            padding: 30px 25px 12px 25px;
            background: linear-gradient(135deg, #E3F2FD 0%, #BBDEFB 100%);
            border-bottom: 1px solid #90CAF9;
            position: relative;
        `;

        const headerContent = document.createElement('div');
        headerContent.style.cssText = `
            display: flex;
            flex-direction: column;
            gap: 10px;
        `;

        const porcentagem = Math.round((resultados.length / totalChamados) * 100);
        const titulo = document.createElement('h3');
        titulo.textContent = `INCs Processados (${resultados.length}/${totalChamados}) - ${porcentagem}%`;
        titulo.style.cssText = `
            margin: 0; 
            font-size: 17px; 
            color: #0D47A1;
            font-weight: 600;
            text-align: center;
        `;
        headerContent.appendChild(titulo);

        const progressContainer = document.createElement('div');
        progressContainer.style.cssText = `
            height: 8px;
            background: #E3F2FD;
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 6px;
            box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
        `;

        const progressBar = document.createElement('div');
        progressBar.style.cssText = `
            height: 100%;
            width: ${porcentagem}%;
            background: linear-gradient(90deg, #42A5F5 0%, #1E88E5 50%, #1565C0 100%);
            border-radius: 4px;
            transition: width 0.4s ease;
            position: relative;
            overflow: hidden;
        `;

        const energyPulse = document.createElement('div');
        energyPulse.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                rgba(255,255,255,0) 0%, 
                rgba(224, 247, 255, 0.6) 50%, 
                rgba(255,255,255,0) 100%);
            animation: energyPulse 1.5s infinite;
            transform: translateX(-100%);
        `;
        progressBar.appendChild(energyPulse);
        progressContainer.appendChild(progressBar);
        headerContent.appendChild(progressContainer);

        const statusIndicator = document.createElement('div');
        statusIndicator.style.cssText = `
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #0D47A1;
            font-weight: 500;
        `;

        const progressText = document.createElement('span');
        progressText.textContent = `Progresso: ${resultados.length} de ${totalChamados} chamados`;

        const percentText = document.createElement('span');
        percentText.textContent = `${porcentagem}% concluído`;
        percentText.style.fontWeight = '600';
        percentText.style.color = porcentagem === 100 ? '#2E7D32' : '#1565C0';

        statusIndicator.appendChild(progressText);
        statusIndicator.appendChild(percentText);
        headerContent.appendChild(statusIndicator);
        header.appendChild(headerContent);

        // Botão de fechar estilo macOS con efecto de explosión
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '&times;';
        closeBtn.style.cssText = `
            position: absolute;
            right: 20px;
            top: 20px;
            background: #ff5f56;
            border: none;
            font-size: 18px;
            cursor: pointer;
            color: white;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.2s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
            z-index: 10001;
            font-weight: bold;
            padding-bottom: 2px;
        `;

        closeBtn.onmouseover = () => {
            closeBtn.style.transform = 'scale(1.15)';
            closeBtn.style.boxShadow = '0 3px 8px rgba(0,0,0,0.2)';
            closeBtn.style.background = '#ff3b30';
        };

        closeBtn.onmouseout = () => {
            closeBtn.style.transform = 'scale(1)';
            closeBtn.style.boxShadow = '0 2px 5px rgba(0,0,0,0.15)';
            closeBtn.style.background = '#ff5f56';
        };

        closeBtn.onclick = (e) => {
            e.stopPropagation();

            const rect = closeBtn.getBoundingClientRect();
            explosionEffect.style.left = `${rect.left + rect.width / 2}px`;
            explosionEffect.style.top = `${rect.top + rect.height / 2}px`;

            explosionEffect.style.opacity = '1';
            explosionEffect.style.transform = 'scale(10)';

            closeBtn.style.transform = 'scale(0.5)';
            closeBtn.style.opacity = '0';

            setTimeout(() => {
                processoAtivo = false;
                controller?.abort();
                resetarEstadosGlobais();
                resetarAparenciaBotoes();

                containerPrincipal.remove();
                explosionEffect.remove();
                if (overlayAtual) {
                    overlayAtual.remove();
                    overlayAtual = null;
                }

                document.removeEventListener('keydown', keyHandler);
            }, 300);
        };

        header.appendChild(closeBtn);
        popup.appendChild(header);

        // Corpo do popup
        const body = document.createElement('div');
        body.style.cssText = `
            padding: 20px;
            overflow-y: auto;
            flex-grow: 1;
            background: #f8f9fa;
        `;

        const chamadosEmAndamento = resultados.filter(r => r.estado === 'Em Andamento');
        const chamadosEmEspera = resultados.filter(r => r.estado === 'Em espera' || r.estado === 'Pausado');
        const chamadosEncerradosValidacao = resultados.filter(r => r.estado === 'Encerrado' || r.estado === 'Validar Solução');
        const outrosChamados = resultados.filter(r => !['Em Andamento', 'Em espera', 'Pausado', 'Validar Solução', 'Encerrado'].includes(r.estado));

        const criarSecaoStatus = (titulo, chamados, cor, corBorda, corFundo, icone) => {
            if (chamados.length === 0) return null;

            const section = document.createElement('div');
            section.style.marginBottom = '30px';

            const header = document.createElement('h4');
            header.textContent = `${titulo.toUpperCase()} (${chamados.length})`;
            header.style.cssText = `
                margin: 0 0 15px 0;
                padding: 10px 15px;
                background: ${cor};
                color: white;
                border-radius: 6px;
                font-size: 15px;
                display: inline-block;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            `;
            section.appendChild(header);

            chamados.forEach((result, index) => {
                const numeroLista = index + 1;

                const bloco = document.createElement('div');
                bloco.style.cssText = `
                    margin-bottom: 15px; 
                    padding: 18px;
                    border-radius: 8px;
                    background: ${corFundo};
                    border-left: 5px solid ${corBorda};
                    position: relative;
                    transition: all 0.3s ease;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
                    cursor: pointer;
                `;

                // Adicionar tag "ATUALIZADO" se o chamado foi atualizado
                if (result.atualizado) {
                    const tagAtualizado = document.createElement('div');
                    tagAtualizado.textContent = 'ATUALIZADO';
                    tagAtualizado.style.cssText = `
                        position: absolute;
                        top: 10px;
                        right: 10px;
                        background: #2196F3;
                        color: white;
                        font-size: 10px;
                        font-weight: bold;
                        padding: 3px 8px;
                        border-radius: 10px;
                        letter-spacing: 0.5px;
                        box-shadow: 0 2px 4px rgba(33, 150, 243, 0.3);
                        z-index: 2;
                    `;
                    bloco.appendChild(tagAtualizado);
                }

                // Adicionar indicador visual se este é o chamado que está sendo atualizado
                if (atualizandoChamados && chamadoAtualizando === result.numeroINC) {
                    bloco.style.boxShadow = `0 0 0 3px ${corBorda}, 0 2px 5px rgba(0,0,0,0.1)`;
                    
                    // Adicionar animação de pulsação para o chamado que está sendo atualizado
                    const pulsatingBorder = document.createElement('div');
                    pulsatingBorder.style.cssText = `
                        position: absolute;
                        top: -3px;
                        left: -3px;
                        right: -3px;
                        bottom: -3px;
                        border-radius: 11px;
                        border: 3px solid ${corBorda};
                        animation: pulsate 1.5s infinite;
                        pointer-events: none;
                        z-index: 1;
                    `;
                    bloco.appendChild(pulsatingBorder);
                    
                    // Adicionar indicador de carregamento
                    const loadingIndicator = document.createElement('div');
                    loadingIndicator.style.cssText = `
                        position: absolute;
                        top: 10px;
                        right: 10px;
                        width: 20px;
                        height: 20px;
                        border: 2px solid rgba(66, 165, 245, 0.3);
                        border-top: 2px solid ${corBorda};
                        border-radius: 50%;
                        animation: spin 1s linear infinite;
                        z-index: 2;
                    `;
                    bloco.appendChild(loadingIndicator);
                    
                    // Adicionar texto "Atualizando..."
                    const updatingText = document.createElement('div');
                    updatingText.textContent = 'Atualizando...';
                    updatingText.style.cssText = `
                        position: absolute;
                        top: 10px;
                        right: 40px;
                        font-size: 12px;
                        font-weight: 600;
                        color: ${corBorda};
                        z-index: 2;
                    `;
                    bloco.appendChild(updatingText);
                }

                // Efeitos hover para feedback visual
                bloco.addEventListener('mouseenter', () => {
                    bloco.style.transform = 'translateY(-2px)';
                    bloco.style.boxShadow = `0 4px 12px rgba(0,0,0,0.1)${atualizandoChamados && chamadoAtualizando === result.numeroINC ? ', 0 0 0 3px ' + corBorda : ''}`;
                    bloco.style.opacity = '0.95';
                });

                bloco.addEventListener('mouseleave', () => {
                    bloco.style.transform = 'translateY(0)';
                    bloco.style.boxShadow = `0 2px 5px rgba(0,0,0,0.05)${atualizandoChamados && chamadoAtualizando === result.numeroINC ? ', 0 0 0 3px ' + corBorda : ''}`;
                    bloco.style.opacity = '1';
                });

                // DOUBLE CLICK PARA ABRIR CHAMADO - NOVA FUNCIONALIDADE
                bloco.addEventListener('dblclick', () => {
                    const url = `https://equatorialenergia.service-now.com/incident.do?sysparm_query=number=${result.numeroINC}`;
                    window.open(url, '_blank');
                });

                bloco.title = 'Duplo clique para abrir este chamado no ServiceNow';

                // 1. BADGE DE STATUS NO TOPO - [EM ANDAMENTO]
                const statusBadge = document.createElement('div');
                statusBadge.style.cssText = `
                    color: ${corBorda}; 
                    font-weight: 600;
                    margin-bottom: 10px;
                    font-size: 14px;
                `;
                statusBadge.textContent = `[${result.estado.toUpperCase()}]`;
                bloco.appendChild(statusBadge);

                // 2. NÚMERO E DESCRIÇÃO DO CHAMADO
                const headerDiv = document.createElement('div');
                headerDiv.style.cssText = `
                    font-weight: 700; 
                    color: #212529; 
                    margin-bottom: 10px; 
                    font-size: 16px;
                `;
                headerDiv.textContent = `${numeroLista}. ${result.numeroINC} - ${result.textoOriginal || ''}`;
                bloco.appendChild(headerDiv);

                const tratativaDiv = document.createElement('div');
                tratativaDiv.style.cssText = `
                    color: #495057; 
                    margin: 8px 0; 
                    font-size: 14px; 
                    line-height: 1.5;
                `;

                const tratativaStrong = document.createElement('strong');
                tratativaStrong.style.color = '#343a40';
                tratativaStrong.textContent = 'Tratativa: ';

                tratativaDiv.appendChild(tratativaStrong);
                tratativaDiv.appendChild(document.createTextNode(result.tratativa));
                bloco.appendChild(tratativaDiv);

                const infoDiv = document.createElement('div');
                infoDiv.style.cssText = `
                    color: #6c757d; 
                    font-size: 13px; 
                    margin: 6px 0; 
                    display: flex; 
                    gap: 15px;
                `;

                const aberturaSpan = document.createElement('span');
                const aberturaStrong = document.createElement('strong');
                aberturaStrong.style.color = '#343a40';
                aberturaStrong.textContent = 'Abertura: ';
                aberturaSpan.appendChild(aberturaStrong);
                aberturaSpan.appendChild(document.createTextNode(result.dataAbertura));
                infoDiv.appendChild(aberturaSpan);

                const atualizacaoSpan = document.createElement('span');
                const atualizacaoStrong = document.createElement('strong');
                atualizacaoStrong.style.color = '#343a40';
                atualizacaoStrong.textContent = 'Atualização: ';
                atualizacaoSpan.appendChild(atualizacaoStrong);
                atualizacaoSpan.appendChild(document.createTextNode(result.ultimaAtividade));
                infoDiv.appendChild(atualizacaoSpan);

                bloco.appendChild(infoDiv);

                if (result.closeNotes) {
                    const notesDiv = document.createElement('div');
                    notesDiv.style.cssText = `
                        margin-top: 12px; 
                        padding: 10px 12px;
                        background: ${corFundo.replace('EE', 'DD')};
                        border-radius: 6px;
                        font-size: 13px;
                        color: #495057;
                        border-left: 3px solid ${corBorda};
                        box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
                    `;

                    const notesStrong = document.createElement('strong');
                    notesStrong.textContent = '📌 Notas: ';
                    notesDiv.appendChild(notesStrong);
                    notesDiv.appendChild(document.createTextNode(result.closeNotes));

                    bloco.appendChild(notesDiv);
                }

                section.appendChild(bloco);
            });

            return section;
        };

        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse {
                0% { box-shadow: 0 0 0 0 rgba(66, 165, 245, 0.4); }
                70% { box-shadow: 0 0 0 12px rgba(66, 165, 245, 0); }
                100% { box-shadow: 0 0 0 0 rgba(66, 165, 245, 0); }
            }
            @keyframes energyPulse {
                0% { transform: translateX(-100%); }
                100% { transform: translateX(100%); }
            }
            @keyframes pulsate {
                0% { opacity: 0.6; transform: scale(1); }
                50% { opacity: 1; transform: scale(1.02); }
                100% { opacity: 0.6; transform: scale(1); }
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);

        if (chamadosEmAndamento.length > 0) {
            body.appendChild(criarSecaoStatus(
                'CHAMADOS EM ANDAMENTO',
                chamadosEmAndamento,
                '#2196F3', '#2196F3', '#E3F2FD', '🔵'
            ));
        }

        if (chamadosEmEspera.length > 0) {
            body.appendChild(criarSecaoStatus(
                'CHAMADOS EM ESPERA',
                chamadosEmEspera,
                '#FF9800', '#FF9800', '#FFF3E0', '🟠'
            ));
        }

        if (chamadosEncerradosValidacao.length > 0) {
            body.appendChild(criarSecaoStatus(
                'CHAMADOS ENCERRADOS/VALIDAÇÃO',
                chamadosEncerradosValidacao,
                '#F44336', '#F44336', '#FFEBEE', '🔴'
            ));
        }

        if (outrosChamados.length > 0) {
            body.appendChild(criarSecaoStatus(
                'OUTROS CHAMADOS',
                outrosChamados,
                '#9E9E9E', '#9E9E9E', '#F5F5F5', '⚪'
            ));
        }

        popup.appendChild(body);

        // Footer
        const footer = document.createElement('div');
        footer.style.cssText = `
            padding: 15px 20px;
            background: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        `;

        const leftContainer = document.createElement('div');
        leftContainer.style.display = 'flex';
        leftContainer.style.gap = '12px';

        const copyBtn = document.createElement('button');
        copyBtn.textContent = 'Copiar Backlog Completo';
        copyBtn.style.cssText = `
            padding: 12px 24px;
            background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        `;

        let podeCopiar = true;
        copyBtn.onclick = () => {
            if (!podeCopiar) return;

            const texto = formatarTextoParaCopiar(resultados);
            navigator.clipboard.writeText(texto)
                .then(() => {
                    copyBtn.textContent = '✓ Copiado!';
                    copyBtn.style.background = 'linear-gradient(135deg, #4CAF50 0%, #2E7D32 100%)';
                    podeCopiar = false;

                    setTimeout(() => {
                        copyBtn.textContent = 'Copiar Backlog Completo';
                        copyBtn.style.background = 'linear-gradient(135deg, #25D366 0%, #128C7E 100%)';
                        podeCopiar = true;
                    }, 1800);
                })
                .catch(err => {
                    console.error('Falha ao copiar texto:', err);
                });
        };
        leftContainer.appendChild(copyBtn);

        const refreshBtn = document.createElement('button');
        refreshBtn.textContent = '🔄 Atualizar';
        refreshBtn.style.cssText = `
            padding: 12px 24px;
            background: linear-gradient(135deg, #2196F3 0%, #0b7dda 100%);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 8px;
        `;
        refreshBtn.onclick = async () => {
            if (!processoAtivo || atualizandoChamados) return;

            atualizandoChamados = true;
            copyBtn.disabled = true;
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<div class="refresh-spinner"></div> Atualizando...';

            const spinnerStyle = document.createElement('style');
            spinnerStyle.textContent = `
                .refresh-spinner {
                    display: inline-block;
                    width: 14px;
                    height: 14px;
                    border: 2px solid rgba(255,255,255,0.3);
                    border-radius: 50%;
                    border-top-color: white;
                    animation: spin 1s ease-in-out infinite;
                }
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(spinnerStyle);

            // Resetar a barra de progresso para 0% no início da atualização
            const progressBar = document.querySelector('#snzx-container .popup-chamados header .progress-container div');
            if (progressBar) {
                progressBar.style.width = '0%';
            }
            
            // Atualizar o título para mostrar que está começando do zero
            const titulo = document.querySelector('#snzx-container .popup-chamados header h3');
            if (titulo) {
                titulo.textContent = `INCs Processados (0/${resultados.length}) - 0%`;
            }

            for (let i = 0; i < resultados.length; i++) {
                if (!processoAtivo) break;

                const chamado = resultados[i];
                const overlay = exibirLoading(resultados.length);
                atualizarProgresso(i, resultados.length);

                try {
                    // Criar popup com indicador visual do chamado que está sendo atualizado
                    criarPopup(resultados, resultados.length, chamado.numeroINC);

                    const novosDados = await consultarChamado(chamado.numeroINC);

                    const mudouEstado = novosDados.estado !== chamado.estado;
                    const mudouTratativa = novosDados.tratativa !== chamado.tratativa;
                    const mudouCloseNotes = novosDados.closeNotes !== chamado.closeNotes;

                    if ((mudouEstado || mudouTratativa || mudouCloseNotes)) {
                        Object.assign(chamado, novosDados);
                        chamado.atualizado = true;
                    }

                    // Aguardar 2.2 segundos entre requisições para evitar bloqueio
                    if (i < resultados.length - 1 && processoAtivo) {
                        await new Promise(resolve => setTimeout(resolve, 2200));
                    }
                } catch (error) {
                    console.error(`Erro ao atualizar ${chamado.numeroINC}:`, error);
                } finally {
                    fecharLoading(overlay);
                }
            }

            // Finalizar o processo de atualização
            atualizandoChamados = false;
            criarPopup(resultados, resultados.length);

            copyBtn.disabled = false;
            refreshBtn.disabled = false;
            refreshBtn.textContent = '🔄 Atualizar';
        };
        leftContainer.appendChild(refreshBtn);

        const rightContainer = document.createElement('div');
        rightContainer.style.display = 'flex';
        rightContainer.style.gap = '10px';
        rightContainer.style.alignItems = 'center';

        const buttonsConfig = [
            { id: 'T1', label: 'T1', color: '#FF9800', nextTurn: 'T2' },
            { id: 'T2', label: 'T2', color: '#2196F3', nextTurn: 'T3' },
            { id: 'T3', label: 'T3', color: '#4CAF50', nextTurn: 'T1' },
            { id: 'N', label: 'N', color: '#9C27B0', tooltip: 'Formata máscara em negrito' },
            { id: 'dash', label: '----', color: '#607D8B', tooltip: 'Adiciona linha divisória' }
        ];

        buttonsConfig.forEach(btnConfig => {
            const btn = document.createElement('button');
            btn.textContent = btnConfig.label;
            btn.dataset.id = btnConfig.id;
            btn.style.cssText = `
                padding: 12px 18px;
                background: #f8f9fa;
                color: #495057;
                border: 1px solid #dee2e6;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 600;
                font-size: 13px;
                transition: all 0.2s;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            `;

            if (btnConfig.tooltip) {
                btn.title = btnConfig.tooltip;
            }

            btn.onclick = () => {
                if (['T1', 'T2', 'T3'].includes(btnConfig.id)) {
                    if (selectedTurn && selectedTurn.id === btnConfig.id) {
                        btn.style.background = '#f8f9fa';
                        btn.style.color = '#495057';
                        btn.style.borderColor = '#dee2e6';
                        selectedTurn = null;
                    } else {
                        document.querySelectorAll('[data-id="T1"], [data-id="T2"], [data-id="T3"]').forEach(b => {
                            b.style.background = '#f8f9fa';
                            b.style.color = '#495057';
                            b.style.borderColor = '#dee2e6';
                        });

                        btn.style.background = btnConfig.color;
                        btn.style.color = 'white';
                        btn.style.borderColor = btnConfig.color;
                        selectedTurn = {
                            id: btnConfig.id,
                            nextTurn: btnConfig.nextTurn
                        };
                    }
                }
                else if (btnConfig.id === 'N') {
                    usarNegrito = !usarNegrito;
                    btn.style.background = usarNegrito ? btnConfig.color : '#f8f9fa';
                    btn.style.color = usarNegrito ? 'white' : '#495057';
                    btn.style.borderColor = usarNegrito ? btnConfig.color : '#dee2e6';
                }
                else if (btnConfig.id === 'dash') {
                    usarDash = !usarDash;
                    btn.style.background = usarDash ? btnConfig.color : '#f8f9fa';
                    btn.style.color = usarDash ? 'white' : '#495057';
                    btn.style.borderColor = usarDash ? btnConfig.color : '#dee2e6';
                }

                copyBtn.textContent = 'Copiar Backlog Completo';
                copyBtn.style.background = 'linear-gradient(135deg, #25D366 0%, #128C7E 100%)';
            };

            rightContainer.appendChild(btn);
        });

        // VOLTAR OS BOTÕES PARA A POSIÇÃO ORIGINAL (Copiar e Atualizar à direita)
        footer.appendChild(rightContainer);
        footer.appendChild(leftContainer);
        popup.appendChild(footer);

        containerPrincipal.appendChild(popup);
        document.body.appendChild(containerPrincipal);

        function keyHandler(e) {
            if (e.key === 'Escape') {
                closeBtn.click();
            }
        }
        document.addEventListener('keydown', keyHandler);

        return containerPrincipal;
    } catch (error) {
        console.error('Erro ao criar popup:', error);
        return null;
    }
}

// ======================
// Processamento de Texto
// ======================
function extrairTextosOriginais(texto) {
    try {
        const linhas = texto.split('\n');
        const mapping = {};

        linhas.forEach(linha => {
            const match = linha.match(/INC\d+/);
            if (match) {
                const inc = match[0];
                const textoRestante = linha.split('-').slice(1).join('-').trim();
                if (textoRestante) {
                    mapping[inc] = textoRestante;
                }
            }
        });

        return mapping;
    } catch (error) {
        console.error('Erro ao extrair textos originais:', error);
        return {};
    }
}

// ======================
// Função Principal
// ======================
async function processarChamadosComDelay(textoSelecionado) {
    resetarEstadosGlobais();
    resetarAparenciaBotoes();
    processoAtivo = true;

    const incs = [...new Set(textoSelecionado.match(/INC\d+/g) || [])];
    
    // Exibir frame de "PROCESSANDO CHAMADOS..." antes de processar
    overlayAtual = exibirLoading(incs.length);

    try {
        const textosOriginais = extrairTextosOriginais(textoSelecionado);
        const resultados = [];

        for (let i = 0; i < incs.length; i++) {
            if (!processoAtivo) {
                console.log('Processo interrompido pelo usuário');
                break;
            }

            const inc = incs[i];
            try {
                atualizarProgresso(i, incs.length);

                const dados = await consultarChamado(inc);
                dados.textoOriginal = textosOriginais[inc] || '';
                dados.atualizado = false;
                resultados.push(dados);

                // Criar popup com indicador visual do chamado que está sendo processado
                criarPopup(resultados, incs.length, inc);

                // Aguardar 2.2 segundos entre requisições para evitar bloqueio
                if (i < incs.length - 1 && processoAtivo) {
                    await new Promise(resolve => setTimeout(resolve, 2200));
                }
            } catch (error) {
                if (error.name !== 'AbortError') {
                    console.error(`Erro no INC ${inc}:`, error);
                }
            }
        }
        
        // Finalizar o processamento sem indicador de atualização
        criarPopup(resultados, incs.length);
    } catch (error) {
        console.error('Erro no processamento principal:', error);
    } finally {
        fecharLoading(overlayAtual);
        overlayAtual = null;
    }
}

// ======================
// Listener de Mensagens
// ======================
browser.runtime.onMessage.addListener(async (request) => {
    if (request.action === "processarTextoSelecionado") {
        processoAtivo = true;
        try {
            await processarChamadosComDelay(request.texto);
        } catch (error) {
            console.error('Erro no listener de mensagens:', error);
        }
    }
});