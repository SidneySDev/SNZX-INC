// ==================================================
// Variáveis Globais
// ==================================================
let selectedText = '';

// ==================================================
// Funções Utilitárias
// ==================================================

async function obterSaudacao() {
  try {
    const res = await fetch('https://worldtimeapi.org/api/timezone/America/Sao_Paulo');
    const { datetime } = await res.json();
    const hora = new Date(datetime).getHours();
    
    return hora < 5 ? "Boa madrugada" :
           hora < 12 ? "Bom dia" :
           hora < 18 ? "Boa tarde" : "Boa noite";
  } catch {
    const hora = new Date().getHours();
    return hora < 5 ? "Boa madrugada" :
           hora < 12 ? "Bom dia" :
           hora < 18 ? "Boa tarde" : "Boa noite";
  }
}

async function gerarCorpoEmail(hosts) {
  try {
    const saudacao = await obterSaudacao();
    return `
Prezados, ${saudacao}!

Favor verificar a causa da falha nos hosts abaixo e enviar o protocolo de acompanhamento.

${hosts.map(host => `- Host: ${host.nome}\n  Designação: ${host.designador}`).join('\n')}

    `.trim();
  } catch (error) {
    console.error('Erro ao gerar o corpo do email:', error);
    return `
Prezados, Olá!

Favor verificar a causa da falha nos hosts abaixo e enviar o protocolo de acompanhamento.

${hosts.map(host => `- Host: ${host.nome}\n  Designação: ${host.designador}`).join('\n')}


    `.trim();
  }
}

// ==================================================
// Função fillFields Original
// ==================================================

function fillFields(selectedText) {
  console.log('Preenchendo campos...');

  const fixedData = {
    caller: 'JOSE BENEDITO SOUZA LOBO',
    item: 'Telecom e Redes - Problemas Gerais',
    symptom: 'Indisponível',
    businessService: 'Radio e Telecomunicação',
    assignmentGroup: 'Monitoramento CGS'
  };

  function fillField(element, value, callback) {
    if (element) {
      element.focus();
      element.value = '';
      let i = 0;
      const typingInterval = setInterval(() => {
        if (i < value.length) {
          element.value += value[i];
          const inputEvent = new Event('input', { bubbles: true });
          element.dispatchEvent(inputEvent);
          const keydownEvent = new Event('keydown', { bubbles: true });
          element.dispatchEvent(keydownEvent);
          i++;
        } else {
          const changeEvent = new Event('change', { bubbles: true });
          element.dispatchEvent(changeEvent);
          clearInterval(typingInterval);
          if (callback) callback();
        }
      }, 2);
    }
  }

  function getLocationFromDescription(description) {
    const regex = /(EQTAL-CL|EQTAL-CC|EQTMA-CL|EQTPA-PA|EQTPI-CL|EQTRS|EQTMA|EQTPI|EQTAL|EQTAP|EQTTR|EQTPA|EQTGO)/;
    const match = description.match(regex);
  
    if (match) {
      const prefix = match[1];
      switch (prefix) {
        case 'EQTRS': return 'EQTL CEEE';
        case 'EQTMA': return 'EQTL Maranhão';
        case 'EQTPI': return 'EQTL Piauí';
        case 'EQTAL': return 'EQTL Alagoas';
        case 'EQTAP': return 'EQTL Amapá';
        case 'EQTTR': return 'COS Equatorial Transmissão';
        case 'EQTPA': return 'EQTL Pará';
        case 'EQTGO': return 'EQTL Goiás';
        case 'EQTAL-CL': return 'Cliente Livre AL';
        case 'EQTAL-CC': return 'Cliente Cativo AL';
        case 'EQTMA-CL': return 'Cliente Livre MA';
        case 'EQTPA-PA': return 'Cliente Livre PA';
        case 'EQTPI-CL': return 'Cliente Livre PI';
        default: return 'EQTL Energia';
      }
    }
    return 'EQTL Energia';
  }

  function fillFieldsSequentially() {
    const callerField = document.getElementById('sys_display.incident.caller_id');
    const locationField = document.getElementById('sys_display.incident.location');
    const itemField = document.getElementById('sys_display.incident.u_item');
    const symptomField = document.getElementById('sys_display.incident.u_symptom');
    const businessServiceField = document.getElementById('sys_display.incident.business_service');
    const assignmentGroupField = document.getElementById('sys_display.incident.assignment_group');
    const descriptionField = document.getElementById('incident.description');
    const workNotesField = document.getElementById('incident.work_notes');
    
    if (callerField && locationField && itemField && symptomField && 
        businessServiceField && assignmentGroupField && descriptionField && workNotesField) {
      const locationValue = getLocationFromDescription(selectedText);
      fillField(callerField, fixedData.caller, () => {
        fillField(locationField, locationValue, () => {
          fillField(itemField, fixedData.item, () => {
            fillField(symptomField, fixedData.symptom, () => {
              fillField(businessServiceField, fixedData.businessService, () => {
                fillField(assignmentGroupField, fixedData.assignmentGroup, () => {
                  descriptionField.value = selectedText;
                  descriptionField.dispatchEvent(new Event('input', { bubbles: true }));
                  descriptionField.dispatchEvent(new Event('change', { bubbles: true }));
                  workNotesField.value = selectedText;
                  workNotesField.dispatchEvent(new Event('input', { bubbles: true }));
                  workNotesField.dispatchEvent(new Event('change', { bubbles: true }));
                  
                  // Aguarda o número do chamado ser gerado
                  const checkNumber = setInterval(() => {
                    const incidentNumber = document.getElementById('sys_readonly.incident.number')?.value;
                    if (incidentNumber) {
                      clearInterval(checkNumber);
                      
                      // Cria um popup estilizado
                      const popup = document.createElement('div');
                      popup.style.position = 'fixed';
                      popup.style.bottom = '20px';
                      popup.style.right = '20px';
                      popup.style.backgroundColor = 'rgba(73, 114, 147, 0.85)';
                      popup.style.backdropFilter = 'blur(10px)';
                      popup.style.padding = '15px 20px';
                      popup.style.borderRadius = '6px';
                      popup.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
                      popup.style.zIndex = '999999';
                      popup.style.fontFamily = "'Helvetica Neue', Arial, sans-serif";
                      popup.style.color = '#ffffff';
                      popup.style.border = '1px solid rgba(255, 255, 255, 0.2)';
                      popup.style.maxWidth = '350px';
                      popup.style.transition = 'all 0.3s ease';
                      popup.style.overflow = 'hidden';
                      popup.style.display = 'flex';
                      popup.style.flexDirection = 'column';
                      popup.style.gap = '12px';
                      
                      // Cria header
                      const header = document.createElement('div');
                      header.style.display = 'flex';
                      header.style.alignItems = 'center';
                      header.style.gap = '10px';
                      
                      // Ícone de notificação
                      const icon = document.createElement('div');
                      icon.innerHTML = '🔔';
                      icon.style.fontSize = '18px';
                      
                      // Título
                      const title = document.createElement('div');
                      title.textContent = 'Chamado Criado';
                      title.style.fontWeight = '600';
                      title.style.fontSize = '15px';
                      
                      header.appendChild(icon);
                      header.appendChild(title);
                      
                      // Texto do chamado
                      const text = document.createElement('div');
                      const fullText = `${incidentNumber} - Gerado para acompanhamento`;
                      text.textContent = fullText;
                      text.style.fontSize = '14px';
                      text.style.lineHeight = '1.4';
                      text.style.wordBreak = 'break-word';
                      
                      // Botão de copiar
                      const copyButton = document.createElement('button');
                      copyButton.textContent = 'Copiar';
                      copyButton.style.padding = '6px 12px';
                      copyButton.style.backgroundColor = 'rgba(255, 255, 255, 0.15)';
                      copyButton.style.color = '#ffffff';
                      copyButton.style.border = '1px solid rgba(255, 255, 255, 0.3)';
                      copyButton.style.borderRadius = '4px';
                      copyButton.style.cursor = 'pointer';
                      copyButton.style.fontSize = '13px';
                      copyButton.style.fontWeight = '500';
                      copyButton.style.transition = 'all 0.2s ease';
                      copyButton.style.alignSelf = 'flex-end';
                      copyButton.style.display = 'flex';
                      copyButton.style.alignItems = 'center';
                      copyButton.style.gap = '6px';
                      
                      // Efeito hover no botão
                      copyButton.onmouseenter = () => {
                        copyButton.style.backgroundColor = 'rgba(255, 255, 255, 0.25)';
                      };
                      copyButton.onmouseleave = () => {
                        copyButton.style.backgroundColor = 'rgba(255, 255, 255, 0.15)';
                      };
                      
                      // Ícone de copiar
                      const copyIcon = document.createElement('span');
                      copyIcon.textContent = '⎘';
                      copyIcon.style.fontSize = '14px';
                      copyButton.prepend(copyIcon);
                      
                      copyButton.addEventListener('click', () => {
                        navigator.clipboard.writeText(fullText);
                        copyButton.innerHTML = '<span style="font-size:14px">✓</span> Copiado!';
                        copyButton.style.backgroundColor = 'rgba(106, 168, 79, 0.7)';
                        setTimeout(() => {
                          popup.remove();
                        }, 1500);
                      });
                      
                      // Adiciona elementos ao popup
                      popup.appendChild(header);
                      popup.appendChild(text);
                      popup.appendChild(copyButton);
                      
                      // Adiciona popup ao body
                      document.body.appendChild(popup);
                      
                      // Remove o popup após 8 segundos
                      setTimeout(() => {
                        if (popup.parentNode) {
                          popup.style.opacity = '0';
                          popup.style.transform = 'translateY(10px)';
                          setTimeout(() => {
                            popup.remove();
                          }, 300);
                        }
                      }, 8000);
                    }
                  }, 500);
                });
              });
            });
          });
        });
      });
    } else {
      console.error('Campos não encontrados');
    }
  }

  const interval = setInterval(() => {
    fillFieldsSequentially();
    clearInterval(interval);
  }, 400);
}

// ==================================================
// Funções para Abertura de Chamados (Outlook Web)
// ==================================================

async function abrirChamadoGenerico(selectedText, urlJson, destinatario) {
  if (!selectedText?.trim()) {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, selecione hosts válidos.",
      iconUrl: "icon.png"
    });
    return;
  }

  try {
    const response = await fetch(urlJson);
    if (!response.ok) throw new Error('Erro ao carregar lista de equipamentos');
    
    const data = await response.json();
    const equipamentos = data.equipamentos;
    const hostnamesSelecionados = selectedText.split(/[\n,]/).map(host => host.trim());
    
    const designadores = hostnamesSelecionados.map(hostname => {
      const equipamento = equipamentos.find(eq => eq.hostname === hostname);
      return equipamento ? 
        { nome: hostname, designador: equipamento.designador } : 
        { nome: hostname, designador: 'NÃO ENCONTRADO' };
    });
    
    if (designadores.length === 0) {
      browser.notifications.create({
        type: "basic",
        title: "Erro",
        message: "Nenhum designador encontrado para os hosts selecionados.",
        iconUrl: "icon.png"
      });
      return;
    }
    
    const corpoEmail = await gerarCorpoEmail(designadores);
    const subject = encodeURIComponent('Abertura de chamado - ');
    const body = encodeURIComponent(corpoEmail);
    
    // URL do Outlook Web com parâmetros otimizados
    const outlookUrl = `https://outlook.office.com/mail/deeplink/compose?to=${destinatario}&cc=noc.cgs@equatorialtelecom.com.br&subject=${subject}&body=${body}`;
    
    // Abre nova aba com pré-preenchimento
    browser.tabs.create({ 
      url: outlookUrl,
      active: true
    });

  } catch (error) {
    console.error(`Erro ao abrir chamado:`, error);
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: `Falha ao gerar email: ${error.message}`,
      iconUrl: "icon.png"
    });
  }
}

async function abrirChamadoTPZ(selectedText) {
  await abrirChamadoGenerico(
    selectedText,
    'https://raw.githubusercontent.com/SidneySDev/SNZX-INC/main/basetpz.json',
    'TPZ.BR.TAC@telespazio.com'
  );
}

async function abrirChamadoHughes(selectedText) {
  await abrirChamadoGenerico(
    selectedText,
    'https://raw.githubusercontent.com/SidneySDev/SNZX-INC/main/hughes.json',
    'helpdesk@hughes.com.br'
  );
}

async function abrirChamadoEbt(selectedText) {
  await abrirChamadoGenerico(
    selectedText,
    'https://raw.githubusercontent.com/SidneySDev/SNZX-INC/main/ebt.json',
    'chamado@atendeembratel.com.br'
  );
}

// ==================================================
// Funções ServiceNow
// ==================================================

function openServiceNow(selectedText) {
  if (!selectedText || selectedText.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, selecione um texto válido.",
      iconUrl: "icon.png"
    });
    return;
  }

  const serviceNowUrl = 'https://equatorialenergia.service-now.com/incident.do?sys_id=-1';

  browser.tabs.create({ url: serviceNowUrl }).then((tab) => {
    const listener = (tabId, changeInfo) => {
      if (tabId === tab.id && changeInfo.status === 'complete') {
        browser.tabs.onUpdated.removeListener(listener);
        
        setTimeout(() => {
          browser.tabs.executeScript(tab.id, {
            code: `(${fillFields.toString()})(${JSON.stringify(selectedText)})`
          }).catch(error => {
            console.error('Erro ao injetar script:', error);
          });
        }, 1800);
      }
    };
    browser.tabs.onUpdated.addListener(listener);
  });
}

function consultarChamadoServiceNow(ticketNumber) {
  if (!ticketNumber || ticketNumber.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, insira um número válido (INC, RITM, KB ou SCTASK).",
      iconUrl: "icon.png"
    });
    return;
  }

  const numeroFormatado = ticketNumber.trim().toUpperCase();
  let serviceNowUrl;
  
  if (numeroFormatado.startsWith('INC')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/incident.do?sysparm_query=number=${numeroFormatado}`;
  } 
  else if (numeroFormatado.startsWith('RITM')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/sc_req_item.do?sysparm_query=number=${numeroFormatado}`;
  } 
  else if (numeroFormatado.startsWith('SCTASK')) {
    serviceNowUrl = `https://equatorialenergia.service-now.com/sc_task.do?sysparm_query=number=${numeroFormatado}`;
  } 
  else if (numeroFormatado.startsWith('KB')){
    serviceNowUrl = `https://equatorialenergia.service-now.com/kb_view.do?sysparm_article=${numeroFormatado}`;
  }
  else if (numeroFormatado.startsWith('CHG')){
    serviceNowUrl =  `https://equatorialenergia.service-now.com/change_request.do?sysparm_query=number=${numeroFormatado}`;
  }
  else if (numeroFormatado.startsWith('CTASK')){
    serviceNowUrl = `https://equatorialenergia.service-now.com/change_task.do?sysparm_query=${numeroFormatado}`;
  }
  else {
    browser.notifications.create({
      type: "basic",
      title: "Formato Inválido",
      message: "Use: INC, RITM, KB, SCTASK, RITM e CTASK seguido de números",
      iconUrl: "icon.png"
    });
    return;
  }

  browser.tabs.create({ url: serviceNowUrl });
}

// ==================================================
// Função para Consultar Chamado Voalle
// ==================================================

function consultarChamadoVoalle(ticketNumber) {
  if (!ticketNumber || ticketNumber.trim() === '') {
    browser.notifications.create({
      type: "basic",
      title: "Erro",
      message: "Por favor, insira um número de chamado válido",
      iconUrl: "icon.png"
    });
    return;
  }

  const numeroLimpo = ticketNumber.replace(/\D/g, '');

  if (!numeroLimpo) {
    browser.notifications.create({
      type: "basic",
      title: "Formato Inválido",
      message: "O número do chamado deve conter apenas dígitos",
      iconUrl: "icon.png"
    });
    return;
  }

  const voalleUrl = `https://erp.equatorialtelecom.com.br/attendance#/customer-attendance/${numeroLimpo}`;
  browser.tabs.create({ url: voalleUrl });
}

// ==================================================
// Configuração do Menu de Contexto
// ==================================================

function setupContextMenu() {
  browser.contextMenus.create({
    id: 'openServiceNow',
    title: '📋 Abrir Chamado no ServiceNow',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'consultarChamadoServiceNow',
    title: '🔍 Consultar Chamado ServiceNow',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'consultarChamadoVoalle',
    title: '📊 Consultar Chamado Voalle',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'abrirChamadoTPZ',
    title: '📧 Abrir Chamado TPZ (Web)',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'abrirChamadoHughes',
    title: '📧 Abrir Chamado Hughes (Web)',
    contexts: ['selection']
  });

  browser.contextMenus.create({
    id: 'abrirChamadoEbt',
    title: '📧 Abrir Chamado Embratel (Web)',
    contexts: ['selection']
  });
}

// ==================================================
// Listener do Menu de Contexto
// ==================================================

browser.contextMenus.onClicked.addListener((info, tab) => {
  selectedText = info.selectionText;
  
  switch (info.menuItemId) {
    case 'openServiceNow':
      openServiceNow(selectedText);
      break;
    case 'abrirChamadoTPZ':
      abrirChamadoTPZ(selectedText);
      break;
    case 'abrirChamadoHughes':
      abrirChamadoHughes(selectedText);
      break;
    case 'abrirChamadoEbt':
      abrirChamadoEbt(selectedText);
      break;
    case 'consultarChamadoServiceNow':
      consultarChamadoServiceNow(selectedText);
      break;
    case 'consultarChamadoVoalle':
      consultarChamadoVoalle(selectedText);
      break;
  }
  
  selectedText = '';
});

// ==================================================
// Inicialização
// ==================================================

setupContextMenu();